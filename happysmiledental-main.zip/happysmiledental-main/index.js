let openMap = () => {
    window.location.assign("https://www.google.com/maps/place/Tahaj+Medical+Hall/@23.2188081,88.3500675,19.77z/data=!4m5!3m4!1s0x39f8e51a792abdc5:0xddc2842e1ef25816!8m2!3d23.2187196!4d88.3503924")
}